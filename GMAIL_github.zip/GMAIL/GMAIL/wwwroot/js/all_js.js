﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification

// Dentro del tag Head se llama asi:
// <script language="JavaScript" src="js\validaciones.js"></script>

var nav4 = window.Event ? true : false;

//--------------------------------------------------------------------------------
function acceptNum(evt)
// Se llama con : onKeyPress="return acceptNum(event)"	
{
    // NOTE: Backspace = 8, Enter = 13, '0' = 48, '9' = 57	
    var key = nav4 ? evt.which : evt.keyCode;
    return (key <= 13 || (key >= 48 && key <= 57));
}

//--------------------------------------------------------------------------------
function validarEmailNecesario(field)
// Se llama con : onBlur="validarEmailNecesario(this);"
// No pasa hasta que no teclea una direccion correcta
{
    if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(field.value)) {

    } else {
        alert("Error, por favor ingrese una dirección de correo electronico valida!");
        field.focus();
        field.value = "";
    }
}

//--------------------------------------------------------------------------------
function validarEmail(field)
// Se llama con : onChange="validarEmail(this);"
// Solo valida la direccion de correo, permite en blanco
{
    if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(field.value)) {

    } else {
        alert("Error, debe ingresar una dirección de correo electronico valida!");
        field.value = "";
    }
}

//--------------------------------------------------------------------------------
function acceptLetters(field)
// Se llama con : onChange=" return acceptLetters(this);"
{
    var str = field.value;
    if (str == "") {
        alert("\nError, el campo esta vacio.\n\nPor favor, debe teclear algun valor.")
        field.focus();
        return false;
    }
    for (var i = 0; i < str.length; i++) {
        var ch = str.substring(i, i + 1);
        if (((ch < "a" || "z" < ch) && (ch < "A" || "Z" < ch)) && ch != ' ') {
            alert("\nEste campo solo acepta letras y espacios.\n\nPor favor, teclee los datos correctos.");
            field.select();
            field.focus();
            return false;
        }
    }
    return true;
}

//--------------------------------------------------------------------------------
function acceptLettersNoBlank(field)
// Se llama con : onChange=" return acceptLettersNoBlank(this);"
{
    var str = field.value;
    for (var i = 0; i < str.length; i++) {
        var ch = str.substring(i, i + 1);
        if (((ch < "a" || "z" < ch) && (ch < "A" || "Z" < ch))) {
            alert("\nEste campo solo acepta letras (sin espacios).\n\nPor favor, teclee los datos correctos.");
            field.select();
            field.focus();
            return false;
        }
    }
    return true;
}

//--------------------------------------------------------------------------------
function limitTextBox(field, cuantos)
// Se llama con onkeypress="return limitTextBox(this, 10);"
{
    if (field.value.length == cuantos) {
        field.select();
        field.focus();
        return false;
    }
    return true;
}

//--------------------------------------------------------------------------------
function checkDecimals(field, decallowed) {
    //Se llama con onClick="checkDecimals(this, 2)"

    //decallowed = 2;  // how many decimals are allowed?

    if (isNaN(field.value) || field.value == "") {
        alert("Error, Por favor, teclee un número.");
        field.select();
        field.focus();
    }
    else {
        if (field.value.indexOf('.') == -1) field.value += ".";
        dectext = field.value.substring(field.value.indexOf('.') + 1, field.value.length);

        if (dectext.length > decallowed) {
            alert("Error, debe teclear un número con " + decallowed + " lugares decimales.");
            field.select();
            field.focus();
        }
    }
}



//--------------------------------------------------------------------------------

function fun_validate_empty(cid_str) {
   // alert(cid_id_str);
    var xxx = document.getElementById(cid_str).value;
    xxx = xxx.replace(" ", "");
    if (xxx.length > 0) {
        return true;
    }
    return false;
}

// call like this
//----------------
//if (fun_validate_empty("CID_name_str")) {
//    //field.select();
//    //field.focus();
//    alert("true");
//}
//else {
//    alert("false");
//}
//----------------

//document.getElementById("Body").innerHTML = "XXX AAA XXX";
//document.getElementById("area21").innerHTML = document.getElementById("area2").innerHTML;

//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------






