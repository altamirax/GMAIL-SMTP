﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Threading.Tasks;
using System.Net.Mail;
using System.Net;



namespace GMAIL.Pages
{

    public class IndexModel : PageModel
    {

            //----------------------------------------
            public string Tb_email { get; set; }
            public string Tb_subject { get; set; }
            //----------------------------------------

            public string Var_str_email_to { get; set; }
            public string Var_str_email_subject { get; set; }
            public string Var_str_email_body { get; set; }

            private string _str_host_name { get; set; }
            private string _str_host_log { get; set; }
            private string _str_host_pas { get; set; }
            private string _str_mail_from { get; set; }

        public void OnGet()  
        {
            // do something
        }

        public async Task OnPostAsync()
        {
            //-----------------------------------
            _str_host_name = "smtp.gmail.com";
            _str_host_log = "altamira.smtp@gmail.com";
            _str_host_pas = "altamira123$";
            _str_mail_from = "xxx_from@gmail.com";
            //-----------------------------------
            Var_str_email_to = Request.Form["Tb_email"].ToString();
            Var_str_email_subject = Request.Form["Tb_subject"].ToString();
            Var_str_email_body = Request.Form["html_textarea"].ToString();
            //-----------------------------------

            //******************
            var smtpClient = new SmtpClient
            {
                Host = _str_host_name, //"smtp.gmail.com", 
                Port = 587, // Port 
                EnableSsl = true,
                Credentials = new NetworkCredential(_str_host_log, _str_host_pas)
            };
            using (var email_message = new MailMessage(_str_mail_from, Var_str_email_to)
            {
                IsBodyHtml = true,
                Subject = Var_str_email_subject,  //Subject = "Subject",
                Body = Var_str_email_body  //"Body"
            })
            {
                await smtpClient.SendMailAsync(email_message);
            }
            //*****************
        }
    }
}



